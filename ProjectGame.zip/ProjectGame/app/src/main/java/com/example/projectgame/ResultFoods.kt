package com.example.projectgame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_result_foods.*

class ResultFoods : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result_foods)

        val totalQuestion = intent.getIntExtra(Foods.TOTAL_QUESTIONS,0)
        val correctAnswer = intent.getIntExtra(Foods.CORRECT_ANSWERS,0)
        tv_scoreF.text = "Your Score is $correctAnswer out of $totalQuestion"
        btn_finishF.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}