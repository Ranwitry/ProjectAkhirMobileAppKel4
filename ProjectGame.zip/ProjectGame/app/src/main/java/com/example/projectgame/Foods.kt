package com.example.projectgame

object Foods {
    const val TOTAL_QUESTIONS: String = "total_question"
    const val CORRECT_ANSWERS: String = "correct_answers"

    fun getQuestions(): ArrayList<Question> {
        val questionfList = ArrayList<Question>()
        val f1 = Question(
            1, "What country does this food belong to?",
            R.drawable.cina, "Armenia", "Brazil", "Hungary", "China", 4
        )
        questionfList.add(f1)

        val f2 = Question(
            2, "What country does this food belong to?",
            R.drawable.india, "Grenada", "India", "Dominika", "North Macedonia", 2
        )
        questionfList.add(f2)

        val f3 = Question(
            3, "What country does this food belong to?",
            R.drawable.indonesia, "Indonesia", "Cambodia", "Philippines", "Irak", 1
        )
        questionfList.add(f3)

        val f4 = Question(
            4, "What country does this food belong to?",
            R.drawable.italia, "United Kingdom", "France", "Italy", "Poland", 3
        )
        questionfList.add(f4)

        val f5 = Question(
            5, "What country does this food belong to?",
            R.drawable.jepang, "South Korea", "Japan", "Rwanda", "Singapore", 2
        )
        questionfList.add(f5)

        val f6 = Question(
            6, "What country does this food belong to?",
            R.drawable.jerman, "Serbia", "South Africa", "Uruguay", "Germany", 4
        )
        questionfList.add(f6)

        val f7 = Question(
            7, "What country does this food belong to?",
            R.drawable.korea, "Vietnam", "South Korea", "North Korea", "Jordan", 2
        )
        questionfList.add(f7)

        val f8 = Question(
            8, "What country does this food belong to?",
            R.drawable.lebanon, "Greek", "Haiti", "Lebanon", "Venezuela", 3
        )
        questionfList.add(f8)

        val f9 = Question(
            9, "What country does this food belong to?",
            R.drawable.meksiko, "Mexico", "USA", "Turkey", "Saudi Arabia", 1
        )
        questionfList.add(f9)

        val f10 = Question(
            10, "What country does this food belong to?",
            R.drawable.thailand, "Laos", "Zimbabwe", "Vietnam", "Thailand", 4
        )
        questionfList.add(f10)

        return questionfList
    }
}