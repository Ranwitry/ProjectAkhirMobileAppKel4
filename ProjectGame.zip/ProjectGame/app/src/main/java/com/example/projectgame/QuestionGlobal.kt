package com.example.projectgame

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_question_global.*
import kotlinx.android.synthetic.main.activity_question_global.btn_submitg
import kotlinx.android.synthetic.main.activity_question_global.option1g
import kotlinx.android.synthetic.main.activity_question_global.option2g
import kotlinx.android.synthetic.main.activity_question_global.option3g
import kotlinx.android.synthetic.main.activity_question_global.option4g
import kotlinx.android.synthetic.main.activity_question_global.progressBarg
import kotlinx.android.synthetic.main.activity_question_global.tv_progressg

class QuestionGlobal : AppCompatActivity(), View.OnClickListener {

    private var CurrentPosition: Int = 1
    private var QuestionList: ArrayList<Global>? = null
    private var OptionPosition: Int = 0
    private var CorrectAnswer: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question_global)
        QuestionList = Obj_Global.getQuestions()
        setQuestion()
        option1g.setOnClickListener(this)
        option2g.setOnClickListener(this)
        option3g.setOnClickListener(this)
        option4g.setOnClickListener(this)
        btn_submitg.setOnClickListener(this)
    }
    private fun setQuestion(){
        val question = QuestionList!![CurrentPosition-1]

        defaultOptionsView()

        if(CurrentPosition == QuestionList!!.size){
            btn_submitg.text = "FINISH"
        }
        else{
            btn_submitg.text = "SUBMIT"
        }

        progressBarg.progress = CurrentPosition
        tv_progressg.text = "$CurrentPosition" + "/" + progressBarg.max
        tv_questiong.text = question!!.question
        option1g.text = question.optionOne
        option2g.text = question.optionTwo
        option3g.text = question.optionThree
        option4g.text = question.optionFour
    }
    private fun defaultOptionsView(){
        val options = arrayListOf<TextView>()
        options.add(0, option1g)
        options.add(1, option2g)
        options.add(2, option3g)
        options.add(3, option4g)

        for (option in options){
            option.setTextColor(Color.parseColor("#7a8089"))
            option.typeface = Typeface.DEFAULT
            option.background = ContextCompat.getDrawable(
                this, R.drawable.border_option
            )
        }

    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.option1g -> {
                selectedOptionView(option1g, 1)
            }
            R.id.option2g -> {
                selectedOptionView(option2g, 2)
            }
            R.id.option3g -> {
                selectedOptionView(option3g, 3)
            }
            R.id.option4g -> {
                selectedOptionView(option4g, 4)
            }
            R.id.btn_submitg -> {
                if(OptionPosition == 0){
                    CurrentPosition++

                    when {
                        CurrentPosition <= QuestionList!!.size -> {
                            setQuestion()
                        }
                        else ->{
                            val intent = Intent(this, ResultGlobal::class.java)
                            intent.putExtra(Obj_Global.CORRECT_ANSWERS, CorrectAnswer)
                            intent.putExtra(Obj_Global.TOTAL_QUESTIONS, QuestionList!!.size)
                            startActivity(intent)
                            finish()
                        }
                    }
                }
                else {
                    val question = QuestionList?.get(CurrentPosition - 1)
                    if (question!!.correctAnswer != OptionPosition) {
                        answerView(OptionPosition, R.drawable.wrong_option)
                    }
                    else{
                        CorrectAnswer++
                    }
                    answerView(question.correctAnswer, R.drawable.corect_option)

                    if (CurrentPosition == QuestionList!!.size){
                        btn_submitg.text = "FINISH"
                    }
                    else{
                        btn_submitg.text = "GO TO THE NEXT QUESTION"
                    }
                    OptionPosition = 0
                }
            }
        }
    }
    private fun answerView(answer: Int, drawableView: Int){
        when(answer){
            1-> {
                option1g.background = ContextCompat.getDrawable(this, drawableView)
            }
            2-> {
                option2g.background = ContextCompat.getDrawable(this, drawableView)
            }
            3-> {
                option3g.background = ContextCompat.getDrawable(this, drawableView)
            }
            4-> {
                option4g.background = ContextCompat.getDrawable(this, drawableView)
            }
        }
    }
    private fun selectedOptionView(tv: TextView, selectedOptionNum: Int){
        defaultOptionsView()
        OptionPosition = selectedOptionNum

        tv.setTextColor(Color.parseColor("#363a43"))
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.background = ContextCompat.getDrawable(
            this, R.drawable.selected_option
        )
    }
}