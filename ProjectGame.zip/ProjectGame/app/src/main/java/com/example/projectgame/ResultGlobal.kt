package com.example.projectgame

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_result.*
import kotlinx.android.synthetic.main.activity_result_global.*

class ResultGlobal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result_global)

        val totalQuestion = intent.getIntExtra(Obj_Global.TOTAL_QUESTIONS,0)
        val correctAnswer = intent.getIntExtra(Obj_Global.CORRECT_ANSWERS,0)
        tv_scoreG.text = "Your Score is $correctAnswer out of $totalQuestion"
        btn_finishG.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}