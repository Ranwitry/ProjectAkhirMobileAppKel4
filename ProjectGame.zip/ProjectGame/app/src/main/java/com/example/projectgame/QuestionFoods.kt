package com.example.projectgame

import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_question_foods.*
import kotlinx.android.synthetic.main.activity_question_foods.btn_submitf
import kotlinx.android.synthetic.main.activity_question_foods.option1f
import kotlinx.android.synthetic.main.activity_question_foods.option2f
import kotlinx.android.synthetic.main.activity_question_foods.option3f
import kotlinx.android.synthetic.main.activity_question_foods.option4f
import kotlinx.android.synthetic.main.activity_question_foods.progressBarf
import kotlinx.android.synthetic.main.activity_question_foods.tv_progressf

class QuestionFoods : AppCompatActivity(), View.OnClickListener {

    private var CurrentPosition: Int = 1
    private var OptionPosition: Int = 0
    private var CorrectAnswer: Int = 0
    private var QuestionList: ArrayList<Question>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question_foods)

        QuestionList = Foods.getQuestions()
        setQuestionf()
        option1f.setOnClickListener(this)
        option2f.setOnClickListener(this)
        option3f.setOnClickListener(this)
        option4f.setOnClickListener(this)
        btn_submitf.setOnClickListener(this)
    }
    private fun setQuestionf(){
        val question = QuestionList!![CurrentPosition-1]

        defaultOptionsView()

        if(CurrentPosition == QuestionList!!.size){
            btn_submitf.text = "FINISH"
        }
        else{
            btn_submitf.text = "SUBMIT"
        }

        progressBarf.progress = CurrentPosition
        tv_progressf.text = "$CurrentPosition" + "/" + progressBarf.max

        tv_questionF.text = question!!.question
        iv_imageQ2f.setImageResource(question.image)
        option1f.text = question.optionOne
        option2f.text = question.optionTwo
        option3f.text = question.optionThree
        option4f.text = question.optionFour
    }
    private fun defaultOptionsView(){
        val options = arrayListOf<TextView>()
        options.add(0, option1f)
        options.add(1, option2f)
        options.add(2, option3f)
        options.add(3, option4f)

        for (option in options){
            option.setTextColor(Color.parseColor("#7a8089"))
            option.typeface = Typeface.DEFAULT
            option.background = ContextCompat.getDrawable(
                this, R.drawable.border_option
            )
        }

    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.option1f -> {
                selectedOptionView(option1f, 1)
            }
            R.id.option2f -> {
                selectedOptionView(option2f, 2)
            }
            R.id.option3f -> {
                selectedOptionView(option3f, 3)
            }
            R.id.option4f -> {
                selectedOptionView(option4f, 4)
            }
            R.id.btn_submitf -> {
                if(OptionPosition == 0){
                    CurrentPosition++

                    when {
                        CurrentPosition <= QuestionList!!.size -> {
                            setQuestionf()
                        }
                        else ->{
                            val intent = Intent(this, ResultFoods::class.java)
                            intent.putExtra(Foods.CORRECT_ANSWERS, CorrectAnswer)
                            intent.putExtra(Foods.TOTAL_QUESTIONS, QuestionList!!.size)
                            startActivity(intent)
                            finish()
                        }
                    }
                }
                else {
                    val question = QuestionList?.get(CurrentPosition - 1)
                    if (question!!.correctAnswer != OptionPosition) {
                        answerView(OptionPosition, R.drawable.wrong_option)
                    }
                    else{
                        CorrectAnswer++
                    }
                    answerView(question.correctAnswer, R.drawable.corect_option)

                    if (CurrentPosition == QuestionList!!.size){
                        btn_submitf.text = "FINISH"
                    }
                    else{
                        btn_submitf.text = "GO TO THE NEXT QUESTION"
                    }
                    OptionPosition = 0
                }
            }
        }
    }
    private fun answerView(answer: Int, drawableView: Int){
        when(answer){
            1-> {
                option1f.background = ContextCompat.getDrawable(this, drawableView)
            }
            2-> {
                option2f.background = ContextCompat.getDrawable(this, drawableView)
            }
            3-> {
                option3f.background = ContextCompat.getDrawable(this, drawableView)
            }
            4-> {
                option4f.background = ContextCompat.getDrawable(this, drawableView)
            }
        }
    }
    private fun selectedOptionView(tv: TextView, selectedOptionNum: Int){
        defaultOptionsView()
        OptionPosition = selectedOptionNum

        tv.setTextColor(Color.parseColor("#363a43"))
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.background = ContextCompat.getDrawable(
            this, R.drawable.selected_option
        )
    }
}